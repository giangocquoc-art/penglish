import { type ReactNode, useRef } from 'react';
import { useGSAP } from '@gsap/react';
import { gsap } from 'gsap';
import { Box, Button, Flex, HStack, Icon, SimpleGrid, Tag, TagLabel, Text } from '@chakra-ui/react';
import { ArrowLeft, ArrowRight, BookOpen, Headphones, HelpCircle, Play, Target, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { EnglishLesson } from '../../lib/p-english/lesson-content-data';
import type { LessonProgressMode } from '../../lib/p-english/lesson-progress';
import { createCardEntrance, safeGsapSet } from '../../lib/animations/gsap-utils';
import { useReducedMotion } from '../../hooks/useReducedMotion';

const COLORS = {
  text: '#0F172A',
  muted: '#64748B',
  primary: '#2563EB',
  green: '#22C55E',
  border: '#E2E8F0',
};

export const PRACTICE_MODE_LABELS: Record<LessonProgressMode, string> = {
  flashcard: 'Flashcard',
  quiz: 'Quiz',
  listen: 'Luyện nghe',
  reflex: 'Phản xạ',
  type: 'Gõ câu',
  match: 'Ghép cặp',
  speed: 'Tốc độ / phát âm',
};

export const PRACTICE_MODE_ICONS: Record<LessonProgressMode, any> = {
  flashcard: BookOpen,
  quiz: HelpCircle,
  listen: Headphones,
  reflex: Zap,
  type: Target,
  match: Target,
  speed: Zap,
};

export function DynamicGuidedLessonFlow({
  lesson,
  activeStep,
  onStepChange,
  learningLocked,
  availableModes,
  speakEnglish,
}: {
  lesson: EnglishLesson;
  activeStep: number;
  onStepChange: (step: number) => void;
  learningLocked: boolean;
  availableModes: LessonProgressMode[];
  speakEnglish: (text: string) => void;
}) {
  const contentRef = useRef<HTMLDivElement | null>(null);
  const reducedMotion = useReducedMotion();
  const steps = availableModes.map((mode) => ({ mode, label: PRACTICE_MODE_LABELS[mode], icon: PRACTICE_MODE_ICONS[mode] }));
  const safeStep = Math.min(activeStep, Math.max(steps.length - 1, 0));
  const step = steps[safeStep];
  const canGoBack = safeStep > 0;
  const canGoNext = safeStep < steps.length - 1;

  useGSAP(
    () => {
      const content = contentRef.current;
      if (!content) return;
      const cards = content.querySelectorAll('.lesson-flow-card, .lesson-speech-bubble');
      if (reducedMotion) {
        safeGsapSet(content, { autoAlpha: 1, y: 0 });
        safeGsapSet(cards, { autoAlpha: 1, y: 0, scale: 1 });
        return;
      }
      gsap.fromTo(content, { autoAlpha: 0, y: 14 }, { autoAlpha: 1, y: 0, duration: 0.34, ease: 'power2.out', force3D: true });
      if (cards.length > 0) createCardEntrance(cards, { y: 14, duration: 0.38, delay: 0.05, stagger: 0.055 });
    },
    { dependencies: [safeStep, reducedMotion], scope: contentRef, revertOnUpdate: true },
  );

  if (!step) {
    return (
      <Box mb="6" bg="white" border="1px solid" borderColor="#BAE6FD" borderRadius="3xl" p={{ base: '5', md: '6' }} boxShadow="0 18px 44px rgba(31, 111, 214, 0.08)">
        <Text fontSize="2xl" fontWeight="950" color={COLORS.text}>Bài này đang ở chế độ đọc nội dung.</Text>
        <Text mt="2" color={COLORS.muted} fontWeight="700">Chưa có mode luyện tập riêng cho bài này. Bạn có thể đọc nội dung bên dưới hoặc quay lại lộ trình để chọn bài khác.</Text>
        <HStack mt="5" wrap="wrap">
          <Button as={Link} to="/learning-path" borderRadius="full" bg={COLORS.primary} color="white">Xem lộ trình</Button>
          <Button as={Link} to="/home" borderRadius="full" variant="outline">Về dashboard</Button>
        </HStack>
      </Box>
    );
  }

  const practiceUrl = `/practice?lessonId=${lesson.id}&mode=${step.mode}`;

  return (
    <Box mb="6" bg="linear-gradient(135deg, rgba(255,255,255,0.94) 0%, rgba(232,244,255,0.92) 52%, rgba(221,245,255,0.86) 100%)" border="1px solid" borderColor="#BAE6FD" borderRadius="3xl" p={{ base: '4', md: '6' }} boxShadow="0 18px 44px rgba(31, 111, 214, 0.10)" overflow="hidden" position="relative">
      <Box position="absolute" right="-58px" top="-70px" w="210px" h="210px" borderRadius="full" bg="rgba(91,188,235,0.18)" />
      <Box position="relative">
        <Flex justify="space-between" align={{ base: 'start', md: 'center' }} direction={{ base: 'column', md: 'row' }} gap="4" mb="5">
          <Box>
            <Tag borderRadius="full" bg="#DDF5FF" color={COLORS.primary} fontWeight="900" mb="2">
              <TagLabel>Bước {safeStep + 1}/{steps.length}</TagLabel>
            </Tag>
            <Text fontSize={{ base: '2xl', md: '3xl' }} fontWeight="950" color={COLORS.text} lineHeight="1.1">
              {step.label}
            </Text>
            <Text mt="2" color={COLORS.muted} fontWeight="700">Các bước được tạo từ mode thật sự có dữ liệu trong bài học này.</Text>
          </Box>
          <HStack gap="2" wrap="wrap">
            {steps.map((item, index) => {
              const selected = index === safeStep;
              return (
                <Button key={item.mode} size="sm" borderRadius="full" leftIcon={<Icon as={item.icon} />} bg={selected ? COLORS.primary : 'white'} color={selected ? 'white' : COLORS.primary} border="1px solid" borderColor={selected ? COLORS.primary : '#BAE6FD'} _hover={{ bg: selected ? '#1D4ED8' : '#EFF6FF' }} onClick={() => onStepChange(index)}>
                  {item.label}
                </Button>
              );
            })}
          </HStack>
        </Flex>
        <Box ref={contentRef} bg="rgba(255,255,255,0.86)" border="1px solid" borderColor="rgba(186,230,253,0.88)" borderRadius="3xl" p={{ base: '4', md: '5' }} willChange="transform, opacity">
          <ModeLearningBlock lesson={lesson} mode={step.mode} speakEnglish={speakEnglish} />
        </Box>
        <Flex mt="5" justify="space-between" align={{ base: 'stretch', sm: 'center' }} direction={{ base: 'column', sm: 'row' }} gap="3">
          <Button onClick={() => onStepChange(Math.max(0, safeStep - 1))} isDisabled={!canGoBack} variant="outline" borderRadius="full" leftIcon={<Icon as={ArrowLeft} />} borderColor="#BAE6FD" color={COLORS.primary}>Quay lại</Button>
          <HStack gap="3" justify={{ base: 'stretch', sm: 'end' }} flexWrap="wrap">
            <Button as={Link} to={practiceUrl} isDisabled={learningLocked} borderRadius="full" bg={COLORS.green} color="white" leftIcon={<Icon as={Play} />} _hover={{ bg: '#16A34A' }}>Luyện ngay</Button>
            <Button onClick={() => onStepChange(Math.min(steps.length - 1, safeStep + 1))} isDisabled={!canGoNext} borderRadius="full" bg={COLORS.primary} color="white" rightIcon={<Icon as={ArrowRight} />} _hover={{ bg: '#1D4ED8' }}>Tiếp tục</Button>
          </HStack>
        </Flex>
      </Box>
    </Box>
  );
}

function ModeLearningBlock({ lesson, mode, speakEnglish }: { lesson: EnglishLesson; mode: LessonProgressMode; speakEnglish: (text: string) => void }) {
  if (mode === 'flashcard') {
    return <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} gap="4">{lesson.vocabulary.slice(0, 6).map((item) => <FlowCard key={item.id} title={item.term} text={item.meaningVi} hint={item.exampleMeaningVi || item.example} onClick={() => speakEnglish(item.term)} />)}</SimpleGrid>;
  }
  if (mode === 'quiz') {
    const items = lesson.quizQuestions.slice(0, 3).map((q) => ({ title: q.question ?? q.prompt ?? q.vietnamese ?? 'Quiz', text: q.options?.join(' • ') ?? q.words?.join(' / ') ?? 'Tự trả lời nhanh.', hint: q.explanationVi ?? 'Mở mode Quiz để kiểm tra.' }));
    return <PreviewList items={items} empty="Chưa có câu quiz để xem trước." />;
  }
  if (mode === 'listen') {
    return <PreviewList items={lesson.listeningPractice.slice(0, 3).map((item) => ({ title: item.question, text: item.text, hint: item.answer }))} empty="Chưa có bài nghe." speakEnglish={speakEnglish} />;
  }
  if (mode === 'reflex') {
    return <PreviewList items={lesson.speakingReflexPrompts.slice(0, 3).map((item) => ({ title: item.promptVi, text: item.hint, hint: item.expectedEnglish }))} empty="Chưa có prompt phản xạ." />;
  }
  if (mode === 'type') {
    const blanks = lesson.fillBlankTasks.slice(0, 2).map((item) => ({ title: item.prompt, text: item.hint || 'Nhìn gợi ý rồi gõ phần còn thiếu trong mode luyện tập.', hint: 'Gõ phần còn thiếu trong mode luyện tập.' }));
    const orders = lesson.sentenceOrderingTasks.slice(0, 2).map((item) => ({ title: item.vietnamese, text: item.words.join(' / '), hint: 'Sắp xếp thành câu đúng.' }));
    return <PreviewList items={[...blanks, ...orders]} empty="Chưa có dữ liệu gõ câu." />;
  }
  if (mode === 'match') {
    const pairs = (lesson.matchPairs ?? []).slice(0, 4).map((item) => ({ title: item.left, text: item.right, hint: 'Ghép hai vế tương ứng.' }));
    const vocabPairs = lesson.vocabulary.slice(0, 4).map((item) => ({ title: item.term, text: item.meaningVi, hint: 'Ghép từ với nghĩa.' }));
    return <PreviewList items={pairs.length > 0 ? pairs : vocabPairs} empty="Chưa có dữ liệu ghép cặp." />;
  }
  return (
    <Flex direction={{ base: 'column', md: 'row' }} gap="4" align="stretch">
      <Box className="lesson-flow-card" flex="1" bg="#EFF6FF" border="1px solid" borderColor="#BAE6FD" borderRadius="2xl" p="5">
        <Text fontSize="2xl" fontWeight="950" color={COLORS.text}>Tốc độ / phát âm</Text>
        <Text mt="2" color={COLORS.muted}>Nhận diện từ/cụm nhanh, luyện miệng đọc chắc hơn trước khi chuyển bài.</Text>
        <SimpleGrid columns={{ base: 1, sm: 3 }} gap="3" mt="4">
          <MiniMetric value={lesson.vocabulary.length} label="từ" />
          <MiniMetric value={lesson.quizQuestions.length} label="quiz" />
          <MiniMetric value="60s" label="mỗi lượt" />
        </SimpleGrid>
      </Box>
      <Box className="lesson-flow-card" w={{ base: '100%', md: '180px' }} bg="white" border="1px solid" borderColor={COLORS.border} borderRadius="2xl" p="5" textAlign="center">
        <Text fontSize="5xl">🐋</Text>
        <Text mt="2" fontWeight="900" color={COLORS.text}>Nhanh mà chắc</Text>
      </Box>
    </Flex>
  );
}

function PreviewList({ items, empty, speakEnglish }: { items: Array<{ title: string; text: string; hint: string }>; empty: string; speakEnglish?: (text: string) => void }) {
  if (items.length === 0) return <Text color={COLORS.muted} fontWeight="800">{empty}</Text>;
  return <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} gap="4">{items.map((item, index) => <FlowCard key={`${item.title}-${index}`} {...item} onClick={speakEnglish ? () => speakEnglish(item.text) : undefined} />)}</SimpleGrid>;
}

function FlowCard({ title, text, hint, onClick }: { title: string; text: string; hint: string; onClick?: () => void }) {
  return (
    <Box className="lesson-flow-card" bg="white" border="1px solid" borderColor={COLORS.border} borderRadius="2xl" p="4" willChange="transform, opacity">
      <HStack justify="space-between" align="start" gap="3">
        <Box minW="0">
          <Text fontWeight="950" color={COLORS.text}>{title}</Text>
          <Text mt="2" color={COLORS.text}>{text}</Text>
          <Text mt="2" color={COLORS.muted} fontSize="sm">{hint}</Text>
        </Box>
        {onClick ? <Button size="xs" borderRadius="full" onClick={onClick}>Nghe</Button> : null}
      </HStack>
    </Box>
  );
}

function MiniMetric({ value, label }: { value: ReactNode; label: string }) {
  return (
    <Box bg="white" border="1px solid" borderColor={COLORS.border} borderRadius="xl" p="3">
      <Text fontWeight="950" color={COLORS.primary}>{value}</Text>
      <Text color={COLORS.muted} fontSize="sm">{label}</Text>
    </Box>
  );
}
